interface HapDB {
  get(key: string): Promise<any>;
  set(key: string, value: any): Promise<void>;
  delete(key: string): Promise<void>;
  list(prefix: string): Promise<Array<{ key: string; value: any }>>;
}

interface HapSystem {
  platform(): Promise<string>;
  arch(): Promise<string>;
  hostname(): Promise<string>;
  listHalModules?(): Promise<any[]>;
  callHalFunction?(module: string, fn: string, params: any): Promise<any>;
  reloadHalModules?(): Promise<void>;
}

interface Hap {
  app: { id: string; version: string; dataDir: string };
  db: HapDB;
  system: HapSystem;
  [key: string]: any;
}

declare global {
  interface Window {
    hap: Hap;
  }
}

export {};
